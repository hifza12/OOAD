﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
namespace POS_SYSTEM
{
    class Connection
    {
       public  static string connection="Data Source =DESKTOP-9IRNH3E\SQLEXPRESS ;initial catalog=posmanagment; Integrated Security = True";
        public static DataTable executeSQL (string sql)
        {
            SqlConnection conection = new SqlConnection ();
            SqlDataAdapter adapter = default(SqlDataAdapter);
            DataTable dt = new DataTable();
            try 
	{	        
                conection.ConnectionString=connection;
                conection.Open();
                adapter = new SqlDataAdapter ();
		
	}
	catch (Exception ex)
	{
		
    System.Windows.Forms.MessageBox.Show("An error occured :"+ ex.Message, "SQL Server connection Failed",MessageBoxButtons.OK ,MessageBoxIcon.Error);
        dt= null;
	}

            return dt;
        }
    }
}
